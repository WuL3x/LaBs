﻿namespace KayumovAE1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lbx = new System.Windows.Forms.ListBox();
            this.btn_discover = new System.Windows.Forms.Button();
            this.lbx_prop = new System.Windows.Forms.ListBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbx
            // 
            this.lbx.FormattingEnabled = true;
            this.lbx.Location = new System.Drawing.Point(18, 20);
            this.lbx.Name = "lbx";
            this.lbx.Size = new System.Drawing.Size(187, 368);
            this.lbx.TabIndex = 0;
            // 
            // btn_discover
            // 
            this.btn_discover.Location = new System.Drawing.Point(17, 398);
            this.btn_discover.Name = "btn_discover";
            this.btn_discover.Size = new System.Drawing.Size(186, 31);
            this.btn_discover.TabIndex = 1;
            this.btn_discover.Text = "Искать устройства";
            this.btn_discover.UseVisualStyleBackColor = true;
            this.btn_discover.Click += new System.EventHandler(this.btn_discover_Click);
            // 
            // lbx_prop
            // 
            this.lbx_prop.BackColor = System.Drawing.SystemColors.Window;
            this.lbx_prop.FormattingEnabled = true;
            this.lbx_prop.Location = new System.Drawing.Point(236, 20);
            this.lbx_prop.Name = "lbx_prop";
            this.lbx_prop.Size = new System.Drawing.Size(535, 368);
            this.lbx_prop.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(236, 398);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(160, 31);
            this.button1.TabIndex = 3;
            this.button1.Text = "Внутренняя информация";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Beige;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbx_prop);
            this.Controls.Add(this.btn_discover);
            this.Controls.Add(this.lbx);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Discovery Bluetooth";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lbx;
        private System.Windows.Forms.Button btn_discover;
        private System.Windows.Forms.ListBox lbx_prop;
        private System.Windows.Forms.Button button1;
    }
}

